-- ====================================================
-- Создаём структуру для слоя DDS DWH:

-- Для HUB'ов
-- Hub #1: User
drop table if exists sperfilyev.dds_t_hub_user cascade;
create table sperfilyev.dds_t_hub_user
(
    user_pk    text,
    user_key   text,
    load_dts   timestamp,
    rec_source text
) distributed randomly;

-- -----------------------------------------
-- Hub #2: Account
drop table if exists sperfilyev.dds_t_hub_account cascade;
create table sperfilyev.dds_t_hub_account
(
    account_pk  text,
    account_key text,
    load_dts    timestamp,
    rec_source  text
)  distributed randomly;

-- -----------------------------------------
-- Hub #3: Billing_period
drop table if exists sperfilyev.dds_t_hub_billing_period cascade;
create table sperfilyev.dds_t_hub_billing_period
(
    billing_period_pk  text,
    billing_period_key text,
    load_dts           timestamp,
    rec_source         text
)  distributed randomly;

-- ----------------------------------------------------------------------
-- Для LINK'ов
-- Link #1: Payment (user - account - billing_period)
drop table if exists sperfilyev.dds_t_lnk_payment cascade;
create table sperfilyev.dds_t_lnk_payment
(
    pay_pk            text,
    user_pk           text,
    account_pk        text,
    billing_period_pk text,
    effective_from    date,
    load_dts          timestamp,
    rec_source        text
)  distributed randomly;

-- ----------------------------------------------------------------------
-- Для SATELLITE'ов

-- Sat #1: User (атрибут phone)
drop table if exists sperfilyev.dds_t_sat_user cascade;
create table sperfilyev.dds_t_sat_user
(
    user_pk        text,
    user_hashdiff  text,
    phone          text,
    effective_from date,
    load_dts       timestamp,
    rec_source     text
)  distributed randomly;

-- -----------------------------------------
-- Sat #2: Payment (саттелит линка, атрибуты платежа)
drop table if exists sperfilyev.dds_t_sat_payment cascade;
create table sperfilyev.dds_t_sat_payment (
    pay_pk text,
    pay_hashdiff text,
    pay_doc_type text,
    pay_doc_num int,
    pay_sum decimal(10,2),
    effective_from date,
    load_dts timestamp,
    rec_source text
)  distributed randomly;
