-- ====================================================
-- Очищаем слой DDS DWH
truncate sperfilyev.dds_t_hub_user;
truncate sperfilyev.dds_t_hub_account;
truncate sperfilyev.dds_t_hub_billing_period;
truncate sperfilyev.dds_t_lnk_payment;
truncate sperfilyev.dds_t_sat_user;
truncate sperfilyev.dds_t_sat_payment;

-- ====================================================
-- Заполняем слой DDS DWH данными из ODS

-- Начальная заливка в хаб(ы)
insert into sperfilyev.dds_t_hub_user (select * from sperfilyev.dds_v_hub_user_etl);
insert into sperfilyev.dds_t_hub_account (select * from sperfilyev.dds_v_hub_account_etl);
insert into sperfilyev.dds_t_hub_billing_period (select * from sperfilyev.dds_v_hub_billing_period_etl);

-- Проверка хаба user
select count(*) from sperfilyev.dds_t_hub_user;
select * from sperfilyev.dds_t_hub_user order by user_key limit 30;

select count(*), load_dts from sperfilyev.dds_t_hub_user
group by load_dts
order by load_dts;

-- Проверка хаба account
select count(*) from sperfilyev.dds_t_hub_account;
select count(distinct account_key) from sperfilyev.dds_t_hub_account;
select count(distinct account) from sperfilyev.ods_t_payment;
select * from sperfilyev.dds_t_hub_account limit 20;

select count(*), load_dts from sperfilyev.dds_t_hub_account
group by load_dts
order by load_dts;

-- Проверка хаба billing_period
select count(*) from sperfilyev.dds_t_hub_billing_period;
select count(distinct billing_period_key) from sperfilyev.dds_t_hub_billing_period;
select * from sperfilyev.dds_t_hub_billing_period;

select count(*), load_dts from sperfilyev.dds_t_hub_billing_period
group by load_dts
order by load_dts;

-- ---------------------------------------------------
-- Начальная заливка в линк(и)
insert into sperfilyev.dds_t_lnk_payment (select * from sperfilyev.dds_v_lnk_payment_etl);

-- Проверка линков
select count(*) from sperfilyev.dds_t_lnk_payment;
select * from sperfilyev.dds_t_lnk_payment limit 10;

select count(*), load_dts from sperfilyev.dds_t_lnk_payment
group by load_dts
order by load_dts;

-- ---------------------------------------------------
-- Начальная заливка в сателлит(ы).
-- С сателлитами история сложнее (см. разборы от 15.04-22.04 и учитывать Лемму Фурмана).
-- Будем загружать их в Airflow
-- ...

-- Проверка сателлитов
select count(*) from sperfilyev.dds_t_sat_user;
select * from sperfilyev.dds_t_sat_user order by user_pk, phone limit 100;

select count(*), load_dts from sperfilyev.dds_t_sat_user
group by load_dts
order by load_dts;

select count(*) from sperfilyev.dds_t_sat_payment;
select * from sperfilyev.dds_t_sat_payment order by effective_from limit 100;

select count(*), load_dts from sperfilyev.dds_t_sat_payment
group by load_dts
order by load_dts;
