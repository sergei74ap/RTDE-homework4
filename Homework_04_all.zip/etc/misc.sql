-- Подключение внешних таблиц
drop external table if exists sperfilyev.stg_t_billing;
create external table sperfilyev.stg_t_billing (
    user_id int,
    billing_period text,
    service text,
    tariff text,
    "sum" decimal(10,2),
    created_at date
    )
    location (
        'pxf://rt-2021-03-25-16-47-29-sfunu-sperfilyev/data_lake/ods/billing/*/?PROFILE=gs:parquet'
        )
    format 'CUSTOM' (
        FORMATTER = 'pxfwritable_import'
        );

drop external table if exists sperfilyev.stg_t_issue;
create external table sperfilyev.stg_t_issue (
    user_id int,
    start_time timestamp,
    end_time timestamp,
    title text,
    description text,
    service text
    )
    location (
        'pxf://rt-2021-03-25-16-47-29-sfunu-sperfilyev/data_lake/ods/issue/*/?PROFILE=gs:parquet'
        )
    format 'CUSTOM' (
        FORMATTER = 'pxfwritable_import'
        );

drop external table if exists sperfilyev.stg_t_traffic;
create external table sperfilyev.stg_t_traffic (
    user_id int,
    "timestamp" timestamp,
    device_id text,
    device_ip_addr text,
    bytes_sent int,
    bytes_received int
    )
    location (
        'pxf://rt-2021-03-25-16-47-29-sfunu-sperfilyev/data_lake/ods/traffic/*/?PROFILE=gs:parquet'
        )
    format 'CUSTOM' (
        FORMATTER = 'pxfwritable_import'
        );

-- Проверки
select * from sperfilyev.stg_t_billing limit 100;
select count(*) from sperfilyev.stg_t_billing;

select * from sperfilyev.stg_t_issue limit 100;
select count(*) from sperfilyev.stg_t_issue;

select * from sperfilyev.stg_t_traffic limit 100;
select count(*) from sperfilyev.stg_t_traffic;

-- ====================================================
-- Создаём слой ODS DWH
drop table if exists sperfilyev.ods_t_billing cascade;
create table sperfilyev.ods_t_billing (
    user_id int,
    billing_period text,
    service text,
    tariff text,
    charged_sum decimal(10,2),
    created_at date
);

drop table if exists sperfilyev.ods_t_issue cascade;
create table sperfilyev.ods_t_issue (
    user_id int,
    start_time timestamp,
    end_time timestamp,
    title text,
    description text,
    service text
);

drop table if exists sperfilyev.ods_t_traffic cascade;
create table sperfilyev.ods_t_traffic (
    user_id int,
    traffic_time timestamp,
    device_id text,
    device_ip_addr text,
    bytes_sent int,
    bytes_received int
);

-- ====================================================
-- Заполняем данными слой ODS DWH
insert into sperfilyev.ods_t_billing (select * from sperfilyev.stg_t_billing);
insert into sperfilyev.ods_t_issue (select * from sperfilyev.stg_t_issue);
insert into sperfilyev.ods_t_traffic (select * from sperfilyev.stg_t_traffic);

--truncate sperfilyev.ods_t_payment;
--truncate sperfilyev.ods_t_payment_hashed;
--insert into sperfilyev.ods_t_payment (select * from sperfilyev.stg_t_payment);

-- Проверки
select count(*) from sperfilyev.ods_t_billing;
select count(*) from sperfilyev.ods_t_issue;
select count(*) from sperfilyev.ods_t_traffic;
select count(*) from sperfilyev.ods_t_payment;

select extract(year from created_at) as charge_year, count(*)
from sperfilyev.ods_t_billing
group by charge_year
order by charge_year;

select extract(year from start_time) as start_year, count(*)
from sperfilyev.ods_t_issue
group by start_year
order by start_year;

select extract(year from traffic_time) as traffic_year, count(*)
from sperfilyev.ods_t_traffic
group by traffic_year
order by traffic_year;

select * from sperfilyev.ods_t_billing limit 10;
select * from sperfilyev.ods_t_issue limit 10;
select * from sperfilyev.ods_t_traffic limit 10;

-- =================================================================
-- эксперименты с Greenplum

create extension if not exists pgcrypto;

-- генерация uuid на базе случайных чисел
select gen_random_uuid();

-- генерация uuid без использования расширений postgresql
select md5(random()::text || ' : ' || clock_timestamp()::text)::uuid;

-- оконные функции
select user_id,
       pay_doc_type,
       pay_doc_num,
       account,
       phone,
       billing_period,
       pay_date,
       pay_sum,
       row_number() over (partition by pay_doc_type order by pay_sum desc)
from sperfilyev.ods_payment
order by user_id, pay_date
limit 100;

select *, cast(avg(pay_sum) over(partition by user_id) as decimal(10, 2)) as avg_sum
from sperfilyev.ods_payment order by avg_sum desc, pay_date asc;

-- CTE (common table expressions)
with top_payments as (
    select user_id, billing_period, pay_sum from sperfilyev.ods_payment order by pay_sum desc limit 20
)
select user_id,
       billing_period,
       pay_sum,
       avg(pay_sum) over ()        as avg_sum,
       min(billing_period) over () as min_period,
       max(billing_period) over () as max_period
from top_payments
order by user_id;

-- ТРЕНИРОВКА 17.04.2021
-- Рассчитываем хэши в слое ODS DWH
drop table if exists sperfilyev.ods_hashed_payment;
create table sperfilyev.ods_hashed_payment
(
    user_id              int,
    pay_doc_type         text,
    pay_doc_num          int,
    account              text,
    phone                text,
    billing_period       text,
    pay_date             date,
    pay_sum              decimal(10, 2),
    id                   text,
    rec_source           text,
    pay_id               text,
    link_payment_account text,
    load_date            date,
    effective_from       date
)
    distributed by (user_id);

create extension if not exists pgcrypto;

with source_data as (
    select user_id,
           pay_doc_type,
           pay_doc_num,
           account,
           phone,
           billing_period,
           pay_date,
           pay_sum
    from sperfilyev.ods_payment
),
     derived_columns as (
         select user_id,
                pay_doc_type,
                pay_doc_num,
                account,
                phone,
                billing_period,
                pay_date,
                pay_sum,
                gen_random_uuid()::text as id,
                'PAYMENT_GATEWAY'::text as rec_source
         from source_data
     ),
     hashed_columns as (
         select user_id,
                pay_doc_type,
                pay_doc_num,
                account,
                phone,
                billing_period,
                pay_date,
                pay_sum,
                id,
                rec_source,
                cast(md5(nullif(upper(trim(cast(id as varchar))), '')) as text) as pay_id,
                cast(md5(nullif(concat_ws('||',
                                          coalesce(nullif(upper(trim(cast(user_id as varchar))), ''), '^^'),
                                          coalesce(nullif(upper(trim(cast(id as varchar))), ''), '^^')
                                    ), '^^||^^')) as text)                      as link_payment_account,
                current_date                                                    as load_date,
                current_date                                                    as effective_from
         from derived_columns
     )
insert
into sperfilyev.ods_hashed_payment
select *
from hashed_columns;

-- Проверки
select count(*) from sperfilyev.ods_hashed_payment;
select * from sperfilyev.ods_hashed_payment limit 100;

-- ============================
-- проверим какие есть неуникальные значения полей user_id, phone
-- (и их неуникальные комбинации) в таблице payments

with dist_sat as (
    select distinct user_pk,
                    user_hashdiff,
                    phone,
                    effective_from,
                    load_dts,
                    rec_source
    from sperfilyev.ods_v_payment)
select count(*) from dist_sat;

with dist_usr_phone as (
    select distinct user_id, phone from sperfilyev.ods_t_payment
)
select count(*) from dist_usr_phone;

select count(*) from sperfilyev.ods_t_payment;
select count(distinct phone) from sperfilyev.ods_t_payment;
select count(distinct user_id) from sperfilyev.ods_t_payment;

with gp as (
    select count(*) as c, phone from sperfilyev.ods_t_payment group by phone order by c desc
)
select gp.*, tp.user_id, tp.pay_date from gp
join sperfilyev.ods_t_payment as tp
on gp.phone = tp.phone
where c>1
order by gp.phone;


with distinct_user_attrs as (
select distinct user_pk, phone, user_hashdiff from sperfilyev.ods_v_payment)
select count(*) from distinct_user_attrs;

select distinct p2013.user_id, p2014.user_id
from sperfilyev.ods_t_payment p2013
left join sperfilyev.ods_t_payment p2014
on p2013.user_id = p2014.user_id
where extract(year from p2013.pay_date)=2013 and
      extract(year from p2014.pay_date)=2014 and
      p2014.user_id is not null;

select * from sperfilyev.dds_t_hub_user;

select distinct user_key from sperfilyev.dds_t_hub_user;
-- 123

select distinct load_dts from sperfilyev.dds_t_hub_user;
-- 2021-04-20 17:31:28.629113


create view sperfilyev.dds_v_hub_user_etl2 as
(
with users_numbered as (
    select user_pk,
           user_key,
           '2013-01-01T00:00:00+00:00'::date as load_dts,
           rec_source,
           row_number() over (partition by user_pk order by load_dts asc) as row_num
    from sperfilyev.ods_v_payment),
     users_rank_1 as (
         select user_pk, user_key, load_dts, rec_source
         from users_numbered
         where row_num = 1),
     records_to_insert as (
         select a.*
         from users_rank_1 as a
                  left join sperfilyev.dds_t_hub_user as h
                            on a.user_pk = h.user_pk
         where h.user_pk is null
     )
select *
from records_to_insert
    );

select * from sperfilyev.dds_v_hub_user_etl2 limit 20;
drop view sperfilyev.dds_v_hub_user_etl2;

    select user_pk,
           user_key,
           '2015-01-15'::date as load_dts,
           rec_source,
           row_number() over (partition by user_pk order by load_dts asc) as row_num
    from sperfilyev.ods_v_payment limit 20;

with users_numbered as (
    select user_pk,
           user_key,
           '2015-01-15'::date as load_dts,
           rec_source,
           row_number() over (partition by user_pk order by load_dts asc) as row_num
    from sperfilyev.ods_v_payment),
     users_rank_1 as (
         select user_pk, user_key, load_dts, rec_source
         from users_numbered
         where row_num = 1)
select * from users_rank_1;


select count (distinct account) from sperfilyev.ods_t_payment
where extract(year from pay_date) = 2013;

select count (distinct billing_period) from sperfilyev.ods_t_payment
where extract(year from pay_date) = 2013;

-- ==============================================
-- This is for Homework_05
select count(*) from sperfilyev.ods_t_payment;
