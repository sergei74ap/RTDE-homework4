-- ====================================================
-- Создаём слой STG DWH
-- Для DWH в качестве слоя STG будем использовать ранее подготовленный ODS Data Lake.
-- Таблицы STG DWH будут находиться в Google Cloud Storage (внешние по отношению к Greenplum)
drop external table if exists sperfilyev.stg_t_payment;
create external table sperfilyev.stg_t_payment (
    user_id int,
    pay_doc_type text,
    pay_doc_num int,
    account text,
    phone text,
    billing_period text,
    pay_date date,
    "sum" decimal(10, 2)
    )
    location (
        'pxf://rt-2021-03-25-16-47-29-sfunu-sperfilyev/data_lake/ods/payment/*/?PROFILE=gs:parquet'
        )
    format 'CUSTOM' (
        FORMATTER = 'pxfwritable_import'
        );

-- Проверки
select * from sperfilyev.stg_t_payment limit 100;
select count(*) from sperfilyev.stg_t_payment;

select distinct extract(month from pay_date) as pay_month,
                extract(year from pay_date) as pay_year
from sperfilyev.stg_t_payment
order by pay_year, pay_month;

-- ====================================================
-- Создаём слой ODS DWH
drop table if exists sperfilyev.ods_t_payment cascade;
create table sperfilyev.ods_t_payment
(
    user_id        int,
    pay_doc_type   text,
    pay_doc_num    int,
    account        text,
    phone          text,
    billing_period text,
    pay_date       date,
    pay_sum        decimal(10, 2),
    load_dts       timestamp,
    rec_source     text
);

-- ====================================================
-- Заполнение слоя ODS данным из STG (попробуем один год)
truncate sperfilyev.ods_t_payment cascade;
insert into sperfilyev.ods_t_payment
    (select stg.*,
            current_timestamp        as load_dts,
            'PAYMENT_DATALAKE'::text as rec_source
     from sperfilyev.stg_t_payment as stg
     where extract(year from stg.pay_date) = 2013);

-- Проверки
select count(*) from sperfilyev.ods_t_payment;
select * from sperfilyev.ods_t_payment limit 10;

select extract(year from pay_date) as pay_year, count(*)
from sperfilyev.ods_t_payment
group by pay_year
order by pay_year;

with dated_records as (
    select *,
       extract(month from pay_date) as pay_month,
       extract(year from pay_date) as pay_year
from sperfilyev.ods_t_payment)
select count(*), pay_month, pay_year
from dated_records
group by pay_year, pay_month
order by pay_year, pay_month;

-- ====================================================
-- Обогащаем слой ODS:
-- Для источника payments подготовим вьюшку со всеми ключами и хэшами
drop view if exists sperfilyev.ods_v_payment cascade;
create view sperfilyev.ods_v_payment as
(
with derived_columns as (
    select *,
           user_id::text            as USER_KEY,
           account::text            as ACCOUNT_KEY,
           billing_period::text     as BILLING_PERIOD_KEY
    from sperfilyev.ods_t_payment
),
     hashed_columns as (
         select *,
                cast(md5(nullif(upper(trim(cast(user_id as varchar))), '')) as text)        as USER_PK,
                cast(md5(nullif(upper(trim(cast(account as varchar))), '')) as text)        as ACCOUNT_PK,
                cast(md5(nullif(upper(trim(cast(billing_period as varchar))), '')) as text) as BILLING_PERIOD_PK,
                cast(md5(nullif(concat_ws('||',
                                          coalesce(nullif(upper(trim(cast(user_id as varchar))), ''), '^^'),
                                          coalesce(nullif(upper(trim(cast(account as varchar))), ''), '^^'),
                                          coalesce(nullif(upper(trim(cast(billing_period as varchar))), ''), '^^')
                                    ), '^^||^^||^^')) as text)                              as PAY_PK,
                cast(md5(nullif(upper(trim(cast(phone as varchar))), '')) as text)          as USER_HASHDIFF,
                cast(md5(nullif(concat_ws('||',
                                          coalesce(nullif(upper(trim(cast(pay_doc_num as varchar))), ''), '^^'),
                                          coalesce(nullif(upper(trim(cast(pay_doc_type as varchar))), ''), '^^'),
                                          coalesce(nullif(upper(trim(cast(pay_sum as varchar))), ''), '^^')
                                    ), '^^||^^||^^')) as text)                              as PAY_HASHDIFF

         from derived_columns
     )
select USER_KEY,
       ACCOUNT_KEY,
       BILLING_PERIOD_KEY,
       USER_PK,
       ACCOUNT_PK,
       BILLING_PERIOD_PK,
       PAY_PK,
       USER_HASHDIFF,
       PAY_HASHDIFF,
       pay_doc_type,
       pay_doc_num,
       pay_sum,
       pay_date,
       phone,
       REC_SOURCE,
       pay_date          as EFFECTIVE_FROM
from hashed_columns
    );

-- Проверки
select * from sperfilyev.ods_v_payment limit 30;
select count(*) from sperfilyev.ods_t_payment;
