CREATE TABLE sperfilyev.ods_t_payment2 AS SELECT * FROM sperfilyev._t_payment;
truncate sperfilyev.ods_t_payment2 cascade;
insert into sperfilyev.ods_t_payment2
    (select stg.*,
            '2014-01-01'::date as load_dts,
            'PAYMENT_DATALAKE'::text as rec_source
     from sperfilyev.stg_t_payment as stg
     where extract(year from stg.pay_date) = 2013);

select extract(year from pay_date) as pay_year, count(*)
from sperfilyev.ods_t_payment2
group by pay_year
order by pay_year;

SELECT COUNT(*) FROM sperfilyev.ods_t_payment2;
SELECT * FROM sperfilyev.ods_t_payment2 LIMIT 10;

drop view if exists sperfilyev.ods_v_payment_etl2 cascade;
create view sperfilyev.ods_v_payment_etl2 as
(
with derived_columns as (
    select *,
           user_id::text            as user_key,
           account::text            as account_key,
           billing_period::text     as billing_period_key
    from sperfilyev.ods_t_payment2
),
     hashed_columns as (
         select *,
                cast(md5(nullif(upper(trim(cast(user_id as varchar))), '')) as text)        as user_pk,
                cast(md5(nullif(upper(trim(cast(account as varchar))), '')) as text)        as account_pk,
                cast(md5(nullif(upper(trim(cast(billing_period as varchar))), '')) as text) as billing_period_pk,
                cast(md5(nullif(concat_ws('||',
                                          coalesce(nullif(upper(trim(cast(user_id as varchar))), ''), '^^'),
                                          coalesce(nullif(upper(trim(cast(account as varchar))), ''), '^^'),
                                          coalesce(nullif(upper(trim(cast(billing_period as varchar))), ''), '^^')
                                    ), '^^||^^||^^')) as text)                              as pay_pk,
                cast(md5(nullif(upper(trim(cast(phone as varchar))), '')) as text)          as user_hashdiff,
                cast(md5(nullif(concat_ws('||',
                                          coalesce(nullif(upper(trim(cast(pay_doc_num as varchar))), ''), '^^'),
                                          coalesce(nullif(upper(trim(cast(pay_doc_type as varchar))), ''), '^^'),
                                          coalesce(nullif(upper(trim(cast(pay_sum as varchar))), ''), '^^')
                                    ), '^^||^^||^^')) as text)                              as pay_hashdiff

         from derived_columns
     )
select user_key,
       account_key,
       billing_period_key,
       user_pk,
       account_pk,
       billing_period_pk,
       pay_pk,
       user_hashdiff,
       pay_hashdiff,
       pay_doc_type,
       pay_doc_num,
       pay_sum,
       phone,
       rec_source,
       load_dts,
       pay_date as effective_from
from hashed_columns
    );

select count(*) from sperfilyev.ods_v_payment_etl2;
select count(*) from sperfilyev.ods_t_payment2;
select * from sperfilyev.ods_v_payment_etl2 limit 10;
select count(*) from sperfilyev.dds_t_sat_user;

-- ===========================================================

drop view if exists sperfilyev.dds_v_sat_user_etl2;
create view sperfilyev.dds_v_sat_user_etl2 as
(
with source_data as (
    select distinct user_pk,
                    user_hashdiff,
                    phone,
                    effective_from,
                    load_dts,
                    rec_source
    from sperfilyev.ods_v_payment_etl2
),
     update_records as (
         select s.*
         from sperfilyev.dds_t_sat_user as s
                  join source_data as src
                       on s.user_pk = src.user_pk
     ),
     latest_records as (
         select *
         from (
                  select user_pk,
                         user_hashdiff,
                         load_dts,
                         row_number() over (partition by user_pk order by load_dts desc) as row_rank
                  from update_records
              ) as numbered_recs
         where row_rank = 1),
     records_to_insert as (
         select a.*
         from source_data as a
                  left join latest_records
                            on latest_records.user_hashdiff = a.user_hashdiff
                                   and
                               latest_records.user_pk = a.user_pk
         where latest_records.user_hashdiff is null
     )
select *
from records_to_insert
    );

select count(*) from sperfilyev.dds_v_sat_user_etl2;

select * from sperfilyev.dds_v_sat_user_etl2
where user_key = '10100'
order by effective_from;

select user_id, count(distinct phone) - count(*) as nondist
from sperfilyev.ods_t_payment2
group by user_id;

select user_id, count(distinct phone) - count(*) as nondist
from sperfilyev.stg_t_payment
group by user_id;

select count(distinct phone) from sperfilyev.stg_t_payment;
