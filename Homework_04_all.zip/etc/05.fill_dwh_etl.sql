-- ====================================================
-- TODO: КАК БУДЕМ ЗАПОЛНЯТЬ СЛОЙ DDS DWH ПРИ ОБНОВЛЕНИЯХ

-- Перед стартом: Обнуляем ODS
truncate sperfilyev.ods_t_payment;
truncate sperfilyev.ods_t_payment_hashed;

-- На каждом проходе: подгружаем в ODS данные за год
delete from sperfilyev.ods_t_payment cascade where extract(year from pay_date) = 2016;
delete from sperfilyev.ods_t_payment_hashed cascade where extract(year from effective_from) = 2015;
insert into sperfilyev.ods_t_payment
    (select * from sperfilyev.stg_t_payment where extract(year from pay_date) = 2016);
insert into sperfilyev.ods_t_payment_hashed
    (select v.*, '2016-01-01'::date as load_dts from sperfilyev.ods_v_payment_etl as v
     where extract(year from v.effective_from) = 2016);
select count(*) from sperfilyev.ods_t_payment_hashed;
select count(*), load_dts from sperfilyev.ods_t_payment_hashed
group by load_dts
order by load_dts;
select * from sperfilyev.ods_t_payment_hashed limit 20;

-- ======================================
-- Загрузка хабов в DDS
select * from sperfilyev.dds_v_hub_user_etl order by user_key;
select count(*) from sperfilyev.dds_v_hub_user_etl;
insert into sperfilyev.dds_t_hub_user select * from sperfilyev.dds_v_hub_user_etl;

select * from sperfilyev.dds_v_hub_account_etl order by account_key;
select count(*) from sperfilyev.dds_v_hub_account_etl;
insert into sperfilyev.dds_t_hub_account select * from sperfilyev.dds_v_hub_account_etl;

select * from sperfilyev.dds_v_hub_billing_period_etl order by billing_period_key;
select count(*) from sperfilyev.dds_v_hub_billing_period_etl;
insert into sperfilyev.dds_t_hub_billing_period select * from sperfilyev.dds_v_hub_billing_period_etl;

-- Проверка хабов
select count(*) from sperfilyev.dds_t_hub_user;
select * from sperfilyev.dds_t_hub_user order by user_key limit 30;

select count(*), load_dts from sperfilyev.dds_t_hub_user
group by load_dts
order by load_dts;

select count(*) from sperfilyev.dds_t_hub_account;
select count(distinct account_key) from sperfilyev.dds_t_hub_account;
select count(distinct account) from sperfilyev.ods_t_payment;
select * from sperfilyev.dds_t_hub_account limit 20;

select count(*), load_dts from sperfilyev.dds_t_hub_account
group by load_dts
order by load_dts;

select count(*) from sperfilyev.dds_t_hub_billing_period;
select count(distinct billing_period_key) from sperfilyev.dds_t_hub_billing_period;
select count(distinct billing_period) from sperfilyev.ods_t_payment;
select * from sperfilyev.dds_t_hub_billing_period order by billing_period_key limit 20;

select count(*), load_dts from sperfilyev.dds_t_hub_billing_period
group by load_dts
order by load_dts;

-- ======================================
-- Загрузка сателлитов в DDS
select * from sperfilyev.dds_v_sat_user_etl order by user_pk, phone limit 50;
select count(*) from sperfilyev.dds_v_sat_user_etl;
select count(*), load_dts from sperfilyev.dds_v_sat_user_etl
group by load_dts
order by load_dts;

insert into sperfilyev.dds_t_sat_user select * from sperfilyev.dds_v_sat_user_etl;

-- Проверка саттелитов
select count(*) from sperfilyev.dds_t_sat_user;
select * from sperfilyev.dds_t_sat_user order by user_pk, phone limit 50;

select count(*), load_dts from sperfilyev.dds_t_sat_user
group by load_dts
order by load_dts;


select count(*), load_dts from sperfilyev.dds_t_sat_payment
group by load_dts
order by load_dts;

with all_payments as (
    select lnk.pay_pk, sat.pay_doc_type, sat.pay_doc_num, sat.pay_sum
    from sperfilyev.dds_t_lnk_payment as lnk
             join sperfilyev.dds_t_sat_payment as sat
                  on lnk.pay_pk = sat.pay_pk)
select *
from all_payments;

-- Проверка объединения линка с его саттелитом
with all_users as (
    select hub.user_pk, hub.user_key, sat.user_hashdiff, sat.phone, sat.effective_from, sat.load_dts, sat.rec_source,
    row_number() over (partition by sat.user_pk order by sat.load_dts desc) as row_num
    from sperfilyev.dds_t_hub_user as hub
             left join sperfilyev.dds_t_sat_user as sat
                  on hub.user_pk = sat.user_pk
)
select count(*)
from all_users
where row_num = 1;


-- Проверка объединения хаба user с его саттелитом
with accs_2013 as (
    select distinct concat_ws(')--(', account, user_id) as st
    from sperfilyev.stg_t_payment
    where extract(year from pay_date)=2013),
     accs_2014 as (
         select distinct concat_ws(')--(', account, user_id) as st
         from sperfilyev.stg_t_payment
         where extract(year from pay_date)=2014),
     accs_2014_new as (
         select * from accs_2014
                           left join accs_2013
                                     on accs_2014.st = accs_2013.st
         where accs_2013.st is null)
select count(*) from accs_2014_new;


select count(*) from sperfilyev.dds_t_hub_billing_period;
select count(distinct billing_period_key) from sperfilyev.dds_t_hub_billing_period;
select * from sperfilyev.dds_t_hub_billing_period;

select count(*), load_dts from sperfilyev.dds_t_hub_billing_period
group by load_dts
order by load_dts;

-- ---------------------------------------------------

-- ---------------------------------------------------
-- Проверка
select count(*) from sperfilyev.dds_t_sat_user;
select * from sperfilyev.dds_t_sat_user limit 30;

select count(*) from sperfilyev.dds_t_sat_payment;
select * from sperfilyev.dds_t_sat_payment limit 30;


select count(*), load_dts from sperfilyev.dds_t_sat_user
group by load_dts
order by load_dts;

--
with dist_usr_sats as (
select distinct user_id, phone
from sperfilyev.stg_t_payment
where extract(year from pay_date)=2014
    )
select count(*) from dist_usr_sats;
--

with dist_usr_phones_2014 as (
    select distinct usr.user_id, sat.phone
    from sperfilyev.stg_t_payment as usr
             join sperfilyev.stg_t_payment as sat
                  on usr.user_id = sat.user_id
    where extract(year from usr.pay_date) = 2014 and
          extract(year from sat.pay_date) = 2014
)
select count(*) from dist_usr_phones_2014;

with dist_usrs_2013 as (
    select distinct user_id
    from sperfilyev.stg_t_payment
    where extract(year from pay_date) = 2013),
dist_phones_2013 as (
    select *
    from sperfilyev.stg_t_payment
    where extract(year from pay_date) = 2013),
dist_2013 as (
    select distinct h.user_id, s.phone
    from dist_usrs_2013 as h
    join dist_phones_2013 as s
    on h.user_id = s.user_id)
select count(*) from dist_2013;

select count(*) from dist_usr_phones_2013;

select count(*) from sperfilyev.stg_t_payment
-- where extract (year from pay_date) = 2021
;
--===============================
--===============================
-- Проверка
select count(*) from sperfilyev.ods_t_payment;
select * from sperfilyev.ods_t_payment limit 10;

select load_dts, count(*)
from sperfilyev.ods_t_payment
group by load_dts
order by load_dts;

select count(*) from sperfilyev.dds_t_hub_user;
select * from sperfilyev.dds_t_hub_user order by user_key limit 30;

select count(*), load_dts from sperfilyev.dds_t_hub_user
group by load_dts
order by load_dts;

select count(*) from sperfilyev.dds_t_sat_user;
select * from sperfilyev.dds_t_sat_user limit 30;

select count(*), load_dts from sperfilyev.dds_t_sat_user
group by load_dts
order by load_dts;

select count(*), load_dts from sperfilyev.dds_t_sat_payment
group by load_dts
order by load_dts;

with dist_usrphones as (
select distinct user_id, phone
from sperfilyev.stg_t_payment)
select count(*) from dist_usrphones;

with dist_usrpayments as (
select distinct user_id, account, billing_period
from sperfilyev.stg_t_payment)
select count(*) from dist_usrpayments;