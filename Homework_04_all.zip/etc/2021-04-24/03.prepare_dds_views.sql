-- ====================================================
-- Готовим ETL-вьюшки для загрузки данных в слой DDS DWH:

-- Для HUB'ов
-- Hub #1: User
drop view if exists sperfilyev.dds_v_hub_user_etl;
create view sperfilyev.dds_v_hub_user_etl as (
with users_numbered as (
    select user_pk,
           user_key,
           load_dts,
           rec_source,
           row_number() over (partition by user_pk order by load_dts asc) as row_num
    from sperfilyev.ods_v_payment_etl),
     users_rank_1 as (
         select user_pk, user_key, load_dts, rec_source
         from users_numbered
         where row_num = 1),
     records_to_insert as (
         select a.*
         from users_rank_1 as a
                  left join sperfilyev.dds_t_hub_user as h
                            on a.user_pk = h.user_pk
         where h.user_pk is null
     )
select *
from records_to_insert
    );

-- Проверки
select * from sperfilyev.dds_v_hub_user_etl limit 20;
select count(*) from sperfilyev.dds_v_hub_user_etl;

-- -----------------------------------------
-- Hub #2: Account
drop view if exists sperfilyev.dds_v_hub_account_etl;
create view sperfilyev.dds_v_hub_account_etl as (
with accounts_numbered as (
    select account_pk,
           account_key,
           load_dts,
           rec_source,
           row_number() over (partition by account_pk order by load_dts asc) as row_num
    from sperfilyev.ods_v_payment_etl),
     accounts_rank_1 as (
         select account_pk, account_key, load_dts, rec_source
         from accounts_numbered
         where row_num = 1),
     records_to_insert as (
         select a.*
         from accounts_rank_1 as a
                  left join sperfilyev.dds_t_hub_account as h
                            on a.account_pk = h.account_pk
         where h.account_pk is null
     )
select *
from records_to_insert
    );

-- Проверка
select * from sperfilyev.dds_v_hub_account_etl order by account_key;
select count(*) from sperfilyev.dds_v_hub_account_etl;
select count(distinct account_key) from sperfilyev.dds_v_hub_account_etl;

-- -----------------------------------------
-- Hub #3: Billing_period
drop view if exists sperfilyev.dds_v_hub_billing_period_etl;
create view sperfilyev.dds_v_hub_billing_period_etl as (
with billing_periods_numbered as (
    select billing_period_pk,
           billing_period_key,
           load_dts,
           rec_source,
           row_number() over (partition by billing_period_pk order by load_dts asc) as row_num
    from sperfilyev.ods_v_payment_etl),
     billing_periods_rank_1 as (
         select billing_period_pk, billing_period_key, load_dts, rec_source
         from billing_periods_numbered
         where row_num = 1),
     records_to_insert as (
         select a.*
         from billing_periods_rank_1 as a
                  left join sperfilyev.dds_t_hub_billing_period as h
                            on a.billing_period_pk = h.billing_period_pk
         where h.billing_period_pk is null
     )
select *
from records_to_insert
    );

-- Проверка
select * from sperfilyev.dds_v_hub_billing_period_etl order by billing_period_key;
select count(*) from sperfilyev.dds_v_hub_billing_period_etl;
select count(distinct billing_period_key) from sperfilyev.dds_v_hub_billing_period_etl;

-- ----------------------------------------------------------------------
-- Для LINK'ов
-- Link #1: Payment (user - account - billing_period)
drop view if exists sperfilyev.dds_v_lnk_payment_etl;
create view sperfilyev.dds_v_lnk_payment_etl as (
select distinct p.pay_pk,
                p.user_pk,
                p.account_pk,
                p.billing_period_pk,
                p.effective_from,
                p.load_dts,
                p.rec_source
from sperfilyev.ods_v_payment_etl as p
         left join sperfilyev.dds_t_lnk_payment as l
                   on p.pay_pk = l.pay_pk
where l.pay_pk is null
);

-- Проверка
select count(*) from sperfilyev.dds_v_lnk_payment_etl;
select * from sperfilyev.dds_v_lnk_payment_etl limit 20;

-- ======================================================================
-- Для SATELLITE'ов

-- Sat #1: User (атрибут phone)
drop view if exists sperfilyev.dds_v_sat_user_etl;
create view sperfilyev.dds_v_sat_user_etl as
(
with source_data as (
    select distinct user_pk,
                    user_hashdiff,
                    phone,
                    effective_from,
                    load_dts,
                    rec_source
    from sperfilyev.ods_v_payment_etl
),
     update_records as (
         select s.*
         from sperfilyev.dds_t_sat_user as s
                  join source_data as src
                       on s.user_pk = src.user_pk
     ),
     latest_records as (
         select *
         from (
                  select user_pk,
                         user_hashdiff,
                         load_dts,
                         rank() over (partition by user_pk order by load_dts desc) as row_rank
                  from update_records
              ) as numbered_recs
         where row_rank = 1),
     records_to_insert as (
         select distinct a.*
         from source_data as a
                  left join latest_records
                            on latest_records.user_hashdiff = a.user_hashdiff and
                               latest_records.user_pk = a.user_pk
         where latest_records.user_hashdiff is null
     )
select *
from records_to_insert
    );

-- Проверки
select count(*) from sperfilyev.dds_v_sat_user_etl;
select * from sperfilyev.dds_v_sat_user_etl limit 30;

-- Проверка на одном юзере
select user_key, user_pk, user_hashdiff, load_dts, effective_from,
row_number() over (partition by user_pk order by load_dts desc) as row_rank
from sperfilyev.ods_v_payment_etl
where user_key like '101__'
order by user_key, row_rank;

-- -----------------------------------------
-- Sat #2: Payment (саттелит линка, атрибуты платежа)
drop view if exists sperfilyev.dds_v_sat_payment_etl;
create view sperfilyev.dds_v_sat_payment_etl as
(
with source_data as (
    select distinct pay_pk,
                    pay_hashdiff,
                    pay_doc_type,
                    pay_doc_num,
                    pay_sum,
                    effective_from,
                    load_dts,
                    rec_source
    from sperfilyev.ods_v_payment_etl
),
     update_records as (
         select s.*
         from sperfilyev.dds_t_sat_payment as s
                  join source_data as src
                       on s.pay_pk = src.pay_pk
     ),
     latest_records as (
         select *
         from (
                  select pay_pk,
                         pay_hashdiff,
                         load_dts,
                         rank() over (partition by pay_pk order by load_dts desc) as row_rank
                  from update_records
              ) as numbered_recs
         where row_rank = 1),
     records_to_insert as (
         select distinct a.*
         from source_data as a
                  left join latest_records
                            on latest_records.pay_hashdiff = a.pay_hashdiff and
                               latest_records.pay_pk = a.pay_pk
         where latest_records.pay_hashdiff is null
     )
select *
from records_to_insert
    );

-- Проверки
select count(*) from sperfilyev.dds_v_sat_payment_etl;
select * from sperfilyev.dds_v_sat_payment_etl limit 30;
