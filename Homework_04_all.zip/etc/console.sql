-- ====================================================
-- Создаём слой STG DWH
-- Для DWH в качестве слоя STG будем использовать ранее подготовленный ODS Data Lake.
-- Таблицы STG DWH будут находиться в Google Cloud Storage (внешние по отношению к Greenplum)
drop external table if exists sperfilyev.stg_t_payment;
create external table sperfilyev.stg_t_payment (
    user_id int,
    pay_doc_type text,
    pay_doc_num int,
    account text,
    phone text,
    billing_period text,
    pay_date date,
    "sum" decimal(10, 2)
    )
    location (
        'pxf://rt-2021-03-25-16-47-29-sfunu-sperfilyev/data_lake/ods/payment/*/?PROFILE=gs:parquet'
        )
    format 'CUSTOM' (
        FORMATTER = 'pxfwritable_import'
        );

-- Проверки
select * from sperfilyev.stg_t_payment limit 100;
select count(*) from sperfilyev.stg_t_payment;

-- ====================================================
-- Создаём слой ODS DWH
drop table if exists sperfilyev.ods_t_payment cascade;
create table sperfilyev.ods_t_payment
(
    user_id        int,
    pay_doc_type   text,
    pay_doc_num    int,
    account        text,
    phone          text,
    billing_period text,
    pay_date       date,
    pay_sum    decimal(10, 2)
);

-- ====================================================
-- Заполняем данными слой ODS DWH
insert into sperfilyev.ods_t_payment (select * from sperfilyev.stg_t_payment);

-- Проверки
select count(*) from sperfilyev.ods_t_payment;
select * from sperfilyev.ods_t_payment limit 10;

select extract(year from pay_date) as pay_year, count(*)
from sperfilyev.ods_t_payment
group by pay_year
order by pay_year;

-- ====================================================
-- Обогащаем слой ODS:
-- Для источника payments подготовим вьюшку со всеми ключами и хэшами
drop view if exists sperfilyev.ods_v_payment cascade;
create view sperfilyev.ods_v_payment as
(
with derived_columns as (
    select *,
           user_id::text            as USER_KEY,
           account::text            as ACCOUNT_KEY,
           billing_period::text     as BILLING_PERIOD_KEY,
           'PAYMENT_DATALAKE'::text as REC_SOURCE
    from sperfilyev.ods_t_payment
),
     hashed_columns as (
         select *,
                cast(md5(nullif(upper(trim(cast(user_id as varchar))), '')) as text)        as USER_PK,
                cast(md5(nullif(upper(trim(cast(account as varchar))), '')) as text)        as ACCOUNT_PK,
                cast(md5(nullif(upper(trim(cast(billing_period as varchar))), '')) as text) as BILLING_PERIOD_PK,
                cast(md5(nullif(concat_ws('||',
                                          coalesce(nullif(upper(trim(cast(user_id as varchar))), ''), '^^'),
                                          coalesce(nullif(upper(trim(cast(account as varchar))), ''), '^^'),
                                          coalesce(nullif(upper(trim(cast(billing_period as varchar))), ''), '^^')
                                    ), '^^||^^||^^')) as text)                              as PAY_PK,
                cast(md5(nullif(upper(trim(cast(phone as varchar))), '')) as text)          as USER_HASHDIFF,
                cast(md5(nullif(concat_ws('||',
                                          coalesce(nullif(upper(trim(cast(pay_doc_num as varchar))), ''), '^^'),
                                          coalesce(nullif(upper(trim(cast(pay_doc_type as varchar))), ''), '^^'),
                                          coalesce(nullif(upper(trim(cast(pay_sum as varchar))), ''), '^^')
                                    ), '^^||^^||^^')) as text)                              as PAY_HASHDIFF

         from derived_columns
     )
select USER_KEY,
       ACCOUNT_KEY,
       BILLING_PERIOD_KEY,
       USER_PK,
       ACCOUNT_PK,
       BILLING_PERIOD_PK,
       PAY_PK,
       USER_HASHDIFF,
       PAY_HASHDIFF,
       pay_doc_type,
       pay_doc_num,
       pay_sum,
       pay_date,
       phone,
       REC_SOURCE,
       current_timestamp as LOAD_DTS,
       pay_date          as EFFECTIVE_FROM
from hashed_columns
    );

select * from sperfilyev.ods_v_payment limit 30;

-- ====================================================
-- Заполняем данными слой DDS DWH:

-- Загружаем HUB'ы
-- Hub #1: User
-- Начальная загрузка в таблицу (первые появления пользователей в источнике в ODS)
drop table if exists sperfilyev.dds_t_hub_user cascade;
create table sperfilyev.dds_t_hub_user as (
    with users_numbered as (
        select user_pk,
               user_key,
               load_dts,
               rec_source,
               row_number() over (partition by user_pk order by load_dts asc) as row_num
        from sperfilyev.ods_v_payment)
    select user_pk, user_key, load_dts, rec_source
    from users_numbered
    where row_num = 1);

-- Проверка
select * from sperfilyev.dds_t_hub_user;
select count(distinct user_key) from sperfilyev.dds_t_hub_user;

-- Вьюшка для последующих дозагрузок данных из ODS в хаб
drop view if exists sperfilyev.dds_v_hub_user_etl;
create view sperfilyev.dds_v_hub_user_etl as
(
with users_numbered as (
    select user_pk,
           user_key,
           load_dts,
           rec_source,
           row_number() over (partition by user_pk order by load_dts asc) as row_num
    from sperfilyev.ods_v_payment),
     users_rank_1 as (
         select user_pk, user_key, load_dts, rec_source
         from users_numbered
         where row_num = 1),
     records_to_insert as (
         select a.*
         from users_rank_1 as a
                  left join sperfilyev.dds_t_hub_user as h
                            on a.user_pk = h.user_pk
         where h.user_pk is null
     )
select *
from records_to_insert
    );

-- Тестируем как вьюшка отработает появление незнакомых записей в ODS
-- сейчас добавлять в хаб нечего, новых записей нет
select * from sperfilyev.dds_v_hub_user_etl;
-- ... а теперь изменим одну запись в ODS
update sperfilyev.ods_t_payment set user_id = 10571 where user_id = 10570;
select distinct user_id from sperfilyev.ods_t_payment where user_id in (10570, 10571) order by user_id desc;
select * from sperfilyev.ods_v_payment where user_key in ('10570', '10571');
-- ... а сейчас вьюшка должна показать новую запись, которой ещё нет в хабе
select * from sperfilyev.dds_v_hub_user_etl;
-- ... а теперь вернём всё как было
update sperfilyev.ods_t_payment set user_id = 10570 where user_id = 10571;
select * from sperfilyev.dds_v_hub_user_etl;

-- Вот так будем дозаливать данные в хаб из ODS
insert into sperfilyev.dds_t_hub_user (select * from sperfilyev.dds_v_hub_user_etl);

-- Проверка
select count(*) from sperfilyev.dds_t_hub_user;
select * from sperfilyev.dds_t_hub_user order by user_key;

-- -----------------------------------------
-- Hub #2: Account
-- Начальная загрузка в таблицу (первые появления счетов в источнике в ODS)
drop table if exists sperfilyev.dds_t_hub_account cascade;
create table sperfilyev.dds_t_hub_account as (
    with accounts_numbered as (
        select account_pk,
               account_key,
               load_dts,
               rec_source,
               row_number() over (partition by account_pk order by load_dts asc) as row_num
        from sperfilyev.ods_v_payment)
    select account_pk, account_key, load_dts, rec_source
    from accounts_numbered
    where row_num = 1);

-- Проверка
select * from sperfilyev.dds_t_hub_account limit 20;
select count(*) from sperfilyev.dds_t_hub_account;
select count(distinct account_key) from sperfilyev.dds_t_hub_account;

-- Вьюшка для последующих дозагрузок данных из ODS в хаб
drop view if exists sperfilyev.dds_v_hub_account_etl;
create view sperfilyev.dds_v_hub_account_etl as
(
with accounts_numbered as (
    select account_pk,
           account_key,
           load_dts,
           rec_source,
           row_number() over (partition by account_pk order by load_dts asc) as row_num
    from sperfilyev.ods_v_payment),
     accounts_rank_1 as (
         select account_pk, account_key, load_dts, rec_source
         from accounts_numbered
         where row_num = 1),
     records_to_insert as (
         select a.*
         from accounts_rank_1 as a
                  left join sperfilyev.dds_t_hub_account as h
                            on a.account_pk = h.account_pk
         where h.account_pk is null
     )
select *
from records_to_insert
    );

-- Вот так будем дозаливать данные в хаб из ODS
insert into sperfilyev.dds_t_hub_account (select * from sperfilyev.dds_v_hub_account_etl);

-- Проверка
select count(*) from sperfilyev.dds_t_hub_account;
select * from sperfilyev.dds_t_hub_account order by account_key;

-- -----------------------------------------
-- Hub #3: Billing_period
-- Начальная загрузка в таблицу (первые появления расчётных периодов в источнике в ODS)
drop table if exists sperfilyev.dds_t_hub_billing_period cascade;
create table sperfilyev.dds_t_hub_billing_period as (
    with billing_periods_numbered as (
        select billing_period_pk,
               billing_period_key,
               load_dts,
               rec_source,
               row_number() over (partition by billing_period_pk order by load_dts asc) as row_num
        from sperfilyev.ods_v_payment)
    select billing_period_pk, billing_period_key, load_dts, rec_source
    from billing_periods_numbered
    where row_num = 1);

-- Проверка
select * from sperfilyev.dds_t_hub_billing_period limit 20;
select count(*) from sperfilyev.dds_t_hub_billing_period;
select count(distinct billing_period_key) from sperfilyev.dds_t_hub_billing_period;

-- Вьюшка для последующих дозагрузок данных из ODS в хаб
drop view if exists sperfilyev.dds_v_hub_billing_period_etl;
create view sperfilyev.dds_v_hub_billing_period_etl as
(
with billing_periods_numbered as (
    select billing_period_pk,
           billing_period_key,
           load_dts,
           rec_source,
           row_number() over (partition by billing_period_pk order by load_dts asc) as row_num
    from sperfilyev.ods_v_payment),
     billing_periods_rank_1 as (
         select billing_period_pk, billing_period_key, load_dts, rec_source
         from billing_periods_numbered
         where row_num = 1),
     records_to_insert as (
         select a.*
         from billing_periods_rank_1 as a
                  left join sperfilyev.dds_t_hub_billing_period as h
                            on a.billing_period_pk = h.billing_period_pk
         where h.billing_period_pk is null
     )
select *
from records_to_insert
    );

-- Вот так будем дозаливать данные в хаб из ODS
insert into sperfilyev.dds_t_hub_billing_period (select * from sperfilyev.dds_v_hub_billing_period_etl);

-- Проверка
select count(*) from sperfilyev.dds_t_hub_billing_period;
select * from sperfilyev.dds_t_hub_billing_period order by billing_period_key;

-- ----------------------------------------------------------------------
-- Загружаем LINK'и

-- Link #1: Payment (user - account - billing_period)
-- Начальная загрузка в таблицу
drop table if exists sperfilyev.dds_t_lnk_payment cascade;
create table sperfilyev.dds_t_lnk_payment as (
    select distinct pay_pk,
                    user_pk,
                    account_pk,
                    billing_period_pk,
                    effective_from,
                    load_dts,
                    rec_source
    from sperfilyev.ods_v_payment);

-- Вьюшка для последующих дозагрузок данных из ODS в линк
drop view if exists sperfilyev.dds_v_lnk_payment_etl;
create view sperfilyev.dds_v_lnk_payment_etl as
(
select distinct p.pay_pk,
                p.user_pk,
                p.account_pk,
                p.billing_period_pk,
                p.effective_from,
                p.load_dts,
                p.rec_source
from sperfilyev.ods_v_payment as p
         left join sperfilyev.dds_t_lnk_payment as l
                   on p.pay_pk = l.pay_pk
where l.pay_pk is null
    );

-- Вот так будем дозаливать данные в линк из ODS
insert into sperfilyev.dds_t_lnk_payment (select * from sperfilyev.dds_v_lnk_payment_etl);

-- Проверка
select count(*) from sperfilyev.dds_t_lnk_payment;
select * from sperfilyev.dds_t_lnk_payment limit 10;

-- ----------------------------------------------------------------------
-- Загружаем SATELLITE'ы

-- Sat #1: User (атрибут phone)
-- Начальная загрузка в таблицу
drop table if exists sperfilyev.dds_t_sat_user cascade;
create table sperfilyev.dds_t_sat_user as (
    select distinct user_pk,
                    user_hashdiff,
                    phone,
                    effective_from,
                    load_dts,
                    rec_source
    from sperfilyev.ods_v_payment
);

-- Вьюшка для последующих дозагрузок данных из ODS в сателлит
drop view if exists sperfilyev.dds_v_sat_user_etl;
create view sperfilyev.dds_v_sat_user_etl as
(
with source_data as (
    select distinct user_pk,
                    user_hashdiff,
                    phone,
                    effective_from,
                    load_dts,
                    rec_source
    from sperfilyev.ods_v_payment
),
     update_records as (
         select s.*
         from sperfilyev.dds_t_sat_user as s
                  join source_data as src
                       on s.user_pk = src.user_pk
     ),
     latest_records as (
         select *
         from (
                  select user_pk,
                         user_hashdiff,
                         load_dts,
                         rank() over (partition by user_pk order by load_dts desc) as row_rank
                  from update_records
              ) as numbered_recs
         where row_rank = 1),
     records_to_insert as (
         select distinct a.*
         from source_data as a
                  left join latest_records
                            on latest_records.user_hashdiff = a.user_hashdiff
         where latest_records.user_hashdiff is null
     )
select *
from records_to_insert
    );

-- Вот так будем дозаливать данные в сателлит из ODS
insert into sperfilyev.dds_t_sat_user (select * from sperfilyev.dds_v_sat_user_etl);

-- Проверки
select count(*) from sperfilyev.dds_v_sat_user_etl;
select count(*) from sperfilyev.dds_t_sat_user;
select * from sperfilyev.dds_v_sat_user_etl limit 30;

-- -----------------------------------------
-- Sat #2: Payment (саттелит линка, атрибуты платежа)
-- Начальная загрузка в таблицу
drop table if exists sperfilyev.dds_t_sat_payment cascade;
create table sperfilyev.dds_t_sat_payment as (
    select distinct pay_pk,
                    pay_hashdiff,
                    pay_doc_type,
                    pay_doc_num,
                    pay_sum,
                    effective_from,
                    load_dts,
                    rec_source
    from sperfilyev.ods_v_payment
);

-- Вьюшка для последующих дозагрузок данных из ODS в сателлит
drop view if exists sperfilyev.dds_v_sat_payment_etl;
create view sperfilyev.dds_v_sat_payment_etl as
(
with source_data as (
    select distinct pay_pk,
                    pay_hashdiff,
                    pay_doc_type,
                    pay_doc_num,
                    pay_sum,
                    effective_from,
                    load_dts,
                    rec_source
    from sperfilyev.ods_v_payment
),
     update_records as (
         select s.*
         from sperfilyev.dds_t_sat_payment as s
                  join source_data as src
                       on s.pay_pk = src.pay_pk
     ),
     latest_records as (
         select *
         from (
                  select pay_pk,
                         pay_hashdiff,
                         load_dts,
                         rank() over (partition by pay_pk order by load_dts desc) as row_rank
                  from update_records
              ) as numbered_recs
         where row_rank = 1),
     records_to_insert as (
         select distinct a.*
         from source_data as a
                  left join latest_records
                            on latest_records.pay_hashdiff = a.pay_hashdiff
         where latest_records.pay_hashdiff is null
     )
select *
from records_to_insert
    );

-- Вот так будем дозаливать данные в сателлит из ODS
insert into sperfilyev.dds_t_sat_payment (select * from sperfilyev.dds_v_sat_payment_etl);

-- Проверки
select count(*) from sperfilyev.dds_v_sat_payment_etl;
select count(*) from sperfilyev.dds_t_sat_payment;
select * from sperfilyev.dds_t_sat_payment limit 30;
select * from sperfilyev.dds_v_sat_payment_etl limit 30;

with all_payments as (
select lnk.pay_pk, sat.pay_doc_type, sat.pay_doc_num, sat.pay_sum from sperfilyev.dds_t_lnk_payment as lnk
join sperfilyev.dds_t_sat_payment as sat
on lnk.pay_pk = sat.pay_pk)
select * from all_payments;

