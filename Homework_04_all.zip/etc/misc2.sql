drop view if exists __source_data cascade;
create view __source_data as
(
select user_pk,
       user_hashdiff,
       phone,
       effective_from,
       load_dts,
       rec_source
from sperfilyev.ods_t_payment_hashed
where load_dts <= '2017-01-01'::timestamp
    );
select load_dts, count(*)
from __source_data
group by load_dts
order by load_dts;
--select count(*) from (select *, rank() over (partition by user_pk order by phone desc) as row_rank from __source_data) as ranked where row_rank=1;

drop view if exists __update_records;
create view __update_records as
(
select distinct s.*
from sperfilyev.dds_t_sat_user as s
         join __source_data as src
              on s.user_pk = src.user_pk and s.load_dts <= (select max(load_dts) from __source_data)
    );
select load_dts, count(*)
from __update_records
group by load_dts
order by load_dts;

drop view if exists __ranked_recs;
create view __ranked_recs as
(
select user_pk,
       user_hashdiff,
       load_dts,
       rank() over (partition by user_pk order by load_dts desc) as row_rank
from __update_records
    );
select load_dts, count(*)
from __ranked_recs
group by load_dts
order by load_dts;
select *
from __ranked_recs
order by user_pk, row_rank, load_dts;
select row_rank, count(*)
from __ranked_recs
group by row_rank
order by row_rank;

drop view if exists __latest_records;
create view __latest_records as
(
select *
from __ranked_recs
where row_rank = 1);
select load_dts, count(*)
from __latest_records
group by load_dts
order by load_dts;
select *
from __latest_records
order by user_pk, row_rank, load_dts;
select row_rank, count(*)
from __latest_records
group by row_rank
order by row_rank;

drop view if exists __records_to_insert;
create view __records_to_insert as
(
select a.*,
       __latest_records.load_dts      as lr_load_dts,
       __latest_records.user_hashdiff as lr_hashdiff,
       __latest_records.row_rank
from __source_data as a
         left join __latest_records
                   on __latest_records.user_hashdiff = a.user_hashdiff and
                      __latest_records.user_pk = a.user_pk
where __latest_records.user_hashdiff is null
    );

select count(*)
from __records_to_insert;
select load_dts, count(*)
from __records_to_insert
group by load_dts
order by load_dts;
select lr_load_dts, count(*)
from __records_to_insert
group by lr_load_dts
order by lr_load_dts;
select distinct *
from __records_to_insert
order by user_pk, load_dts;

select load_dts, count(*)
from __records_to_insert
where load_dts = '2016-01-01'::date
group by load_dts
order by load_dts;

insert into sperfilyev.dds_t_sat_user
with source_data as (
    select user_pk,
           user_hashdiff,
           phone,
           effective_from,
           load_dts,
           rec_source
    from sperfilyev.ods_t_payment_hashed
    where extract(year from load_dts) = 2013
),
     update_records as (
         select s.*
         from sperfilyev.dds_t_sat_user as s
                  join source_data as src
                       on s.user_pk = src.user_pk and s.load_dts <= (select max(load_dts) from source_data)
     ),
     latest_records as (
         select *
         from (
                  select user_pk,
                         user_hashdiff,
                         load_dts,
                         rank() over (partition by user_pk order by load_dts desc) as row_rank
                  from update_records
              ) as ranked_recs
         where row_rank = 1),
     records_to_insert as (
         select distinct a.*
         from source_data as a
                  left join latest_records
                            on latest_records.user_hashdiff = a.user_hashdiff and
                               latest_records.user_pk = a.user_pk
         where latest_records.user_hashdiff is null
     )
select * from records_to_insert;
